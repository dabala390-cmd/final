-- =================================================
-- import.sql
-- Executed automatically by Hibernate AFTER
-- entity tables are created
-- =================================================


-- ===============================
-- ROLES
-- ===============================
INSERT INTO roles (name, created_at, updated_at)
VALUES
    ('ADMIN', NOW(), NOW()),
    ('CLIENT', NOW(), NOW())
    ON CONFLICT (name) DO NOTHING;


-- ===============================
-- OPTIONAL: DEFAULT SYSTEM DATA
-- (NO USERS, NO PASSWORDS)
-- ===============================
-- Add only lookup/static data here
-- Never add credentials in import.sql
