-- ===============================
-- ROLES
-- ===============================
INSERT INTO roles (id, name, created_at, updated_at)
VALUES
    (1, 'ADMIN', NOW(), NOW()),
    (2, 'CLIENT', NOW(), NOW())
    ON CONFLICT (id) DO NOTHING;

-- ===============================
-- USERS (ADMIN)
-- NOTE: full_name is REQUIRED in your User entity
-- Password: admin123
-- ===============================
INSERT INTO users (
    id,
    username,
    password_hash,
    email,
    full_name,
    active,
    created_at,
    updated_at
)
VALUES (
           1,
           'admin',
           '$2b$10$ZdOC9INd8wGvpCF5hYUFOuzCQ/.vWS3XypOFxl7/SJkJz6bVKLuJa',
           'admin2@northwollo.com',
           'System Administrator',
           true,
           NOW(),
           NOW()
       )
    ON CONFLICT (id) DO NOTHING;

-- ===============================
-- USER ROLES
-- ===============================
INSERT INTO user_roles (user_id, role_id)
VALUES (1, 1)
    ON CONFLICT DO NOTHING;
