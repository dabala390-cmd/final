package com.northwollo.tourism.dto.response;

import lombok.Data;

@Data
public class HorseServiceDto {

    private String ownerName;
    private String contactInfo;
    private double cost;
}
