package com.northwollo.tourism.dto.response;

import com.northwollo.tourism.entity.HotelRating;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class HotelRatingResponseDto {

    private Long id;
    private int rating;
    private String comment;
    private String userFullName;
    private LocalDateTime createdAt;

    // Convert HotelRating entity to DTO
    public static HotelRatingResponseDto fromEntity(HotelRating rating) {
        HotelRatingResponseDto dto = new HotelRatingResponseDto();
        dto.setId(rating.getId());
        dto.setRating(rating.getRating());
        dto.setComment(rating.getFeedback());
        dto.setCreatedAt(rating.getCreatedAt());

        if (rating.getUser() != null) {
            dto.setUserFullName(rating.getUser().getFullName());
        }

        return dto;
    }
}
