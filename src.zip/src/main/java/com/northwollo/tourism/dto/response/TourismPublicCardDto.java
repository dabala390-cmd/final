package com.northwollo.tourism.dto.response;

import com.northwollo.tourism.entity.TourismPlace;
import lombok.Data;

@Data
public class TourismPublicCardDto {
    private Long id;
    private String name;
    private String imageUrl;
    private int viewersCount;

    // ✅ Add a constructor
    public TourismPublicCardDto(Long id, String name, String imageUrl, int viewersCount) {
        this.id = id;
        this.name = name;
        this.imageUrl = imageUrl;
        this.viewersCount = viewersCount;
    }

    // Optional: static helper
    public static TourismPublicCardDto fromEntity(TourismPlace place) {
        String imageUrl = null;
        if (place.getImages() != null && !place.getImages().isEmpty()) {
            imageUrl = place.getImages().get(0).getImageUrl();
        }
        return new TourismPublicCardDto(
                place.getId(),
                place.getName(),
                imageUrl,
                place.getViewersCount()
        );
    }
}
