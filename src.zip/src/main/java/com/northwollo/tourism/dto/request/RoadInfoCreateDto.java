package com.northwollo.tourism.dto.request;

import com.northwollo.tourism.enums.RoadType;
import lombok.Data;

@Data
public class RoadInfoCreateDto {
    private Long tourismPlaceId;
    private RoadType roadType;
    private String description;
    private Double distanceByCar;
    private Double distanceByFoot;
    private Double distanceByPlane;
    private Double distanceByHorse;
}
