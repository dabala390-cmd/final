package com.northwollo.tourism.dto.response;

import lombok.Data;

@Data
public class MapRouteResponseDto {
    private String from;
    private String to;
    private double distanceKm;
    private String routeInfo;
}
