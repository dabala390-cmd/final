package com.northwollo.tourism.enums;

public enum PlaceStatus {
    ACTIVE,
    BLOCKED
}
