package com.northwollo.tourism.enums;

public enum RoadType {
    CAR,
    FOOT,
    HORSE
}
