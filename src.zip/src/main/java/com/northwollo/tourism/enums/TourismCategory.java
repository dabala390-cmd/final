package com.northwollo.tourism.enums;

public enum TourismCategory {
    HERITAGE,
    HIGHLAND,
    CAVERN,
    AQUATICS,
    CULTURE,
    MODERN
}
