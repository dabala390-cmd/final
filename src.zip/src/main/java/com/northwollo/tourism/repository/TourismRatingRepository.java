package com.northwollo.tourism.repository;

import com.northwollo.tourism.entity.TourismRating;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface TourismRatingRepository
        extends JpaRepository<TourismRating, Long> {

    List<TourismRating> findByTourismPlaceId(Long tourismPlaceId);

    long countByTourismPlaceId(Long tourismPlaceId);

    @Query("select avg(r.rating) from TourismRating r where r.tourismPlace.id = :id")
    Double averageRating(Long id);
}
