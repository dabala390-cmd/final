package com.northwollo.tourism.repository;

import com.northwollo.tourism.entity.TourismPlace;
import com.northwollo.tourism.enums.PlaceStatus;
import com.northwollo.tourism.enums.TourismCategory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TourismPlaceRepository extends JpaRepository<TourismPlace, Long> {

    @Query("""
        SELECT tp FROM TourismPlace tp
        WHERE tp.status = :status
        AND (:categories IS NULL OR tp.category IN :categories)
        AND (:keyword IS NULL OR LOWER(tp.name) LIKE LOWER(CONCAT('%', :keyword, '%')))
    """)
    Page<TourismPlace> searchPublic(
            @Param("categories") List<TourismCategory> categories,
            @Param("keyword") String keyword,
            @Param("status") PlaceStatus status,
            Pageable pageable
    );

    List<TourismPlace> findTop5ByKebeleAndIdNotAndStatus(String kebele, Long id, PlaceStatus status);
}
