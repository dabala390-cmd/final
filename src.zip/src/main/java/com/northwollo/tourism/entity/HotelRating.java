package com.northwollo.tourism.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "hotel_ratings")
@Getter
@Setter
public class HotelRating extends BaseEntity {

    @ManyToOne(optional = false)
    @JoinColumn(name = "hotel_id")
    private Hotel hotel;

    @ManyToOne(optional = false)
    @JoinColumn(name = "user_id")
    private User user;

    @Min(1)
    @Max(5)
    private int rating;

    @Column(length = 1000)
    private String feedback;
}
