package com.northwollo.tourism.controller;

import com.northwollo.tourism.enums.TourismCategory;
import com.northwollo.tourism.service.TourismService;
import com.northwollo.tourism.dto.response.TourismPublicCardDto;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/tourism")
@RequiredArgsConstructor
public class PublicTourismController {

    private final TourismService tourismService;

    @GetMapping
    public ResponseEntity<Page<TourismPublicCardDto>> list(
            @RequestParam(required = false) String category, // comma-separated
            @RequestParam(required = false) String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        // Convert comma-separated string to List<TourismCategory>
        List<TourismCategory> categoriesList = null;
        if (category != null && !category.isBlank()) {
            categoriesList = Arrays.stream(category.split(","))
                    .map(String::trim)
                    .map(TourismCategory::valueOf)
                    .collect(Collectors.toList());
        }

        // Create Pageable object
        Pageable pageable = PageRequest.of(page, size);

        Page<TourismPublicCardDto> result = tourismService.listPublic(categoriesList, keyword, pageable);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> basicDetail(@PathVariable Long id) {
        // You might want to return minimal DTO for public view
        return ResponseEntity.ok(tourismService.getFullDetail(id));
    }
}
