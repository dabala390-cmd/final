package com.northwollo.tourism.controller;

import com.northwollo.tourism.dto.response.SearchResultDto;
import com.northwollo.tourism.dto.response.TourismListDto;
import com.northwollo.tourism.enums.TourismCategory;
import com.northwollo.tourism.service.SearchService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/public/search")
@RequiredArgsConstructor
public class SearchController {

    private final SearchService searchService;

    /**
     * PUBLIC SEARCH:
     * - Filter by multiple categories (checkboxes)
     * - Search by keyword (name, wereda, kebele, description, etc.)
     * - Sorted by popularity (viewersCount DESC by default)
     */
    @GetMapping("/tourism")
    public SearchResultDto<TourismListDto> searchTourismPlaces(
            @RequestParam(required = false) List<TourismCategory> categories,
            @RequestParam(required = false) String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "viewersCount") String sortBy,
            @RequestParam(defaultValue = "DESC") Sort.Direction direction
    ) {

        Pageable pageable = PageRequest.of(
                page,
                size,
                Sort.by(direction, sortBy)
        );

        return searchService.searchTourismPlaces(
                categories,
                keyword,
                pageable
        );
    }
}
