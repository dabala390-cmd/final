package com.northwollo.tourism.controller;

import com.northwollo.tourism.dto.response.MapRouteResponseDto;
import com.northwollo.tourism.service.MapService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/map")
@RequiredArgsConstructor
public class MapController {

    private final MapService mapService;

    // Calculate route & distance
    @GetMapping("/route")
    public ResponseEntity<MapRouteResponseDto> getRoute(
            @RequestParam String from,
            @RequestParam String to) {
        return ResponseEntity.ok(mapService.calculateRoute(from, to));
    }
}
