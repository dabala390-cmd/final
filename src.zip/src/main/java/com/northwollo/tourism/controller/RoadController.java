package com.northwollo.tourism.controller;

import com.northwollo.tourism.service.RoadService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/roads")
@RequiredArgsConstructor
public class RoadController {

    private final RoadService roadService;

    @GetMapping("/by-tourism/{tourismPlaceId}")
    public ResponseEntity<?> getRoads(
            @PathVariable Long tourismPlaceId) {
        return ResponseEntity.ok(
                roadService.getRoadsByTourismPlace(tourismPlaceId)
        );
    }

    @GetMapping("/{roadId}/horse")
    public ResponseEntity<?> getHorseService(
            @PathVariable Long roadId) {
        return ResponseEntity.ok(
                roadService.getHorseServiceByRoad(roadId)
        );
    }
}
