package com.northwollo.tourism.util;

public class FilterUtils {

    // TODO: Implement filtering methods for tourism categories, popular places, etc.
    public static boolean matchesCategory(String placeCategory, String filterCategory) {
        // Placeholder
        return placeCategory.equalsIgnoreCase(filterCategory);
    }
}
