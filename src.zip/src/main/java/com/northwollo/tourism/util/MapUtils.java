package com.northwollo.tourism.util;

public class MapUtils {

    // TODO: Implement helper methods for map and route calculations
    public static double calculateDistanceKm(String from, String to) {
        // Placeholder
        return 0.0;
    }

    public static String generateRouteInfo(String from, String to) {
        // Placeholder
        return "Route details placeholder";
    }
}
