package com.northwollo.tourism.util;

import java.util.List;

public class RatingUtils {

    // TODO: Helper to calculate average rating
    public static double calculateAverage(List<Integer> ratings) {
        if (ratings == null || ratings.isEmpty()) return 0.0;
        int sum = 0;
        for (int r : ratings) sum += r;
        return sum / (double) ratings.size();
    }
}
