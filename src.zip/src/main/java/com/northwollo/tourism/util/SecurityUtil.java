package com.northwollo.tourism.util;

import com.northwollo.tourism.entity.User;
import com.northwollo.tourism.exception.AccessDeniedException;
import com.northwollo.tourism.repository.UserRepository;
import com.northwollo.tourism.security.UserPrincipal;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
public class SecurityUtil {

    private static UserRepository userRepository;

    public SecurityUtil(UserRepository userRepository) {
        SecurityUtil.userRepository = userRepository;
    }

    public static User getCurrentUser() {

        Authentication authentication =
                SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || !authentication.isAuthenticated()) {
            throw new AccessDeniedException("User not authenticated");
        }

        Object principal = authentication.getPrincipal();

        if (!(principal instanceof UserPrincipal userPrincipal)) {
            throw new AccessDeniedException("Invalid authentication principal");
        }

        return userRepository.findById(userPrincipal.getId())
                .orElseThrow(() -> new AccessDeniedException("User not found"));
    }
}
