package com.northwollo.tourism.service.impl;

import com.northwollo.tourism.dto.request.HotelRatingRequestDto;
import com.northwollo.tourism.entity.Hotel;
import com.northwollo.tourism.entity.HotelRating;
import com.northwollo.tourism.entity.User;
import com.northwollo.tourism.exception.ResourceNotFoundException;
import com.northwollo.tourism.repository.HotelRatingRepository;
import com.northwollo.tourism.repository.HotelRepository;
import com.northwollo.tourism.service.HotelRatingService;
import com.northwollo.tourism.util.SecurityUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class HotelRatingServiceImpl implements HotelRatingService {

    private final HotelRepository hotelRepository;
    private final HotelRatingRepository ratingRepository;

    @Override
    public void addRating(HotelRatingRequestDto dto) {
        Hotel hotel = hotelRepository.findById(dto.getHotelId())
                .orElseThrow(() -> new ResourceNotFoundException("Hotel not found"));

        User user = SecurityUtil.getCurrentUser();

        HotelRating hr = new HotelRating();
        hr.setHotel(hotel);
        hr.setUser(user);
        hr.setRating(dto.getRating());
        hr.setFeedback(dto.getFeedback());

        ratingRepository.save(hr);
    }

    @Override
    public List<HotelRating> getRatingsByHotel(Long hotelId) {
        return ratingRepository.findByHotelId(hotelId);
    }
}
