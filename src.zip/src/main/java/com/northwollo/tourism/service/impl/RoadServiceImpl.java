package com.northwollo.tourism.service.impl;

import com.northwollo.tourism.dto.response.HorseServiceDto;
import com.northwollo.tourism.dto.response.RoadInfoDto;
import com.northwollo.tourism.entity.HorseService;
import com.northwollo.tourism.entity.RoadInfo;
import com.northwollo.tourism.exception.ResourceNotFoundException;
import com.northwollo.tourism.repository.HorseServiceRepository;
import com.northwollo.tourism.repository.RoadInfoRepository;
import com.northwollo.tourism.service.RoadService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class RoadServiceImpl implements RoadService {

    private final RoadInfoRepository roadRepository;
    private final HorseServiceRepository horseRepository;

    @Override
    public List<RoadInfoDto> getRoadsByTourismPlace(Long tourismPlaceId) {
        return roadRepository.findByTourismPlaceId(tourismPlaceId)
                .stream()
                .map(this::mapToDto)
                .toList();
    }

    @Override
    public HorseServiceDto getHorseServiceByRoad(Long roadId) {
        HorseService horse = horseRepository.findByRoadInfoId(roadId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Horse service not found for road: " + roadId));

        HorseServiceDto dto = new HorseServiceDto();
        dto.setOwnerName(horse.getOwnerName());
        dto.setContactInfo(horse.getContactInfo());
        dto.setCost(horse.getCost());
        return dto;
    }

    private RoadInfoDto mapToDto(RoadInfo road) {
        RoadInfoDto dto = new RoadInfoDto();
        dto.setId(road.getId());
        dto.setRoadType(road.getRoadType() != null ? road.getRoadType().name() : null); // convert enum to String
        dto.setDescription(road.getDescription());
        dto.setDistanceByCar(road.getDistanceByCar());
        dto.setDistanceByFoot(road.getDistanceByFoot());
        dto.setDistanceByHorse(road.getDistanceByHorse());
        dto.setTotalDistance(road.getTotalDistance());
        return dto;
    }

}
