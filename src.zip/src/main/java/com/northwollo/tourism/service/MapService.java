package com.northwollo.tourism.service;

import com.northwollo.tourism.dto.response.MapRouteResponseDto;

public interface MapService {
    MapRouteResponseDto calculateRoute(String from, String to);
}
