package com.northwollo.tourism.service;

import com.northwollo.tourism.dto.response.HorseServiceDto;
import com.northwollo.tourism.dto.response.RoadInfoDto;

import java.util.List;

public interface RoadService {

    List<RoadInfoDto> getRoadsByTourismPlace(Long tourismPlaceId);

    HorseServiceDto getHorseServiceByRoad(Long roadId);
}
