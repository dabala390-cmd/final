package com.northwollo.tourism.service.impl;

import com.northwollo.tourism.dto.request.TourismRatingRequestDto;
import com.northwollo.tourism.entity.TourismPlace;
import com.northwollo.tourism.entity.TourismRating;
import com.northwollo.tourism.entity.User;
import com.northwollo.tourism.exception.ResourceNotFoundException;
import com.northwollo.tourism.repository.TourismPlaceRepository;
import com.northwollo.tourism.repository.TourismRatingRepository;
import com.northwollo.tourism.service.TourismRatingService;
import com.northwollo.tourism.util.SecurityUtil; // utility to get current user
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class TourismRatingServiceImpl implements TourismRatingService {

    private final TourismRatingRepository ratingRepository;
    private final TourismPlaceRepository tourismRepository;

    @Override
    public void addRating(TourismRatingRequestDto dto) {

        TourismPlace place = tourismRepository.findById(dto.getTourismPlaceId())
                .orElseThrow(() -> new ResourceNotFoundException("Tourism place not found"));

        // Get the currently logged-in user
        User user = SecurityUtil.getCurrentUser();

        TourismRating rating = new TourismRating();
        rating.setTourismPlace(place);
        rating.setUser(user);
        rating.setRating(dto.getRating());
        rating.setComment(dto.getComment());

        ratingRepository.save(rating);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TourismRating> getRatingsByTourism(Long tourismPlaceId) {

        if (!tourismRepository.existsById(tourismPlaceId)) {
            throw new ResourceNotFoundException("Tourism place not found");
        }

        return ratingRepository.findByTourismPlaceId(tourismPlaceId);
    }
}
