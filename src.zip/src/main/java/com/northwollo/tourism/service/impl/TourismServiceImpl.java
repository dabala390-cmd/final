package com.northwollo.tourism.service.impl;

import com.northwollo.tourism.dto.request.TourismCreateDto;
import com.northwollo.tourism.dto.request.TourismUpdateDto;
import com.northwollo.tourism.dto.response.*;
import com.northwollo.tourism.entity.Hotel;
import com.northwollo.tourism.entity.RoadInfo;
import com.northwollo.tourism.entity.TourismPlace;
import com.northwollo.tourism.entity.TourismRating;
import com.northwollo.tourism.enums.PlaceStatus;
import com.northwollo.tourism.enums.TourismCategory;
import com.northwollo.tourism.exception.ResourceNotFoundException;
import com.northwollo.tourism.repository.HotelRepository;
import com.northwollo.tourism.repository.RoadInfoRepository;
import com.northwollo.tourism.repository.TourismPlaceRepository;
import com.northwollo.tourism.repository.TourismRatingRepository;
import com.northwollo.tourism.service.TourismService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class TourismServiceImpl implements TourismService {

    private final TourismPlaceRepository tourismRepository;
    private final RoadInfoRepository roadInfoRepository;
    private final HotelRepository hotelRepository;
    private final TourismRatingRepository ratingRepository;

    @Override
    public Long create(TourismCreateDto dto) {
        TourismPlace place = new TourismPlace();
        place.setName(dto.getName());
        place.setCategory(dto.getCategory());
        place.setDescription(dto.getDescription());
        place.setWereda(dto.getWereda());
        place.setKebele(dto.getKebele());
        place.setBestTime(dto.getBestTime());
        place.setPeaceInfo(dto.getPeaceInfo());
        place.setLanguages(dto.getLanguages() != null && !dto.getLanguages().isBlank()
                ? Arrays.asList(dto.getLanguages().split(",")) : List.of());
        place.setImageUrl(dto.getImageUrl() != null ? dto.getImageUrl() : null);
        place.setStatus(PlaceStatus.ACTIVE);
        place.setViewersCount(0);
        if (dto.getVisitTime() != null && !dto.getVisitTime().isBlank()) {
            place.setVisitTime(Duration.parse(dto.getVisitTime()));
        }
        tourismRepository.save(place);
        return place.getId();
    }

    @Override
    public void update(Long id, TourismUpdateDto dto) {
        TourismPlace place = tourismRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Tourism place not found: " + id));
        if (dto.getName() != null) place.setName(dto.getName());
        if (dto.getCategory() != null) place.setCategory(dto.getCategory());
        if (dto.getDescription() != null) place.setDescription(dto.getDescription());
        if (dto.getWereda() != null) place.setWereda(dto.getWereda());
        if (dto.getKebele() != null) place.setKebele(dto.getKebele());
        place.setBestTime(dto.getBestTime());
        place.setPeaceInfo(dto.getPeaceInfo());
        place.setLanguages(dto.getLanguages());
        place.setImageUrl(dto.getImageUrl());
        place.setStatus(dto.getStatus());
        if (dto.getVisitTime() != null && !dto.getVisitTime().isBlank()) {
            place.setVisitTime(Duration.parse(dto.getVisitTime()));
        }
    }

    @Override
    public void delete(Long id) {
        if (!tourismRepository.existsById(id)) {
            throw new ResourceNotFoundException("Tourism place not found: " + id);
        }
        tourismRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TourismPublicCardDto> listPublic(List<TourismCategory> categories, String keyword, Pageable pageable) {
        Page<TourismPlace> page = tourismRepository.searchPublic(categories, keyword, PlaceStatus.ACTIVE, pageable);
        return page.map(tp -> new TourismPublicCardDto(
                tp.getId(),
                tp.getName(),
                tp.getImages() != null && !tp.getImages().isEmpty() ? tp.getImages().get(0).getImageUrl() : null,
                tp.getViewersCount()
        ));
    }

    @Override
    public TourismFullDetailDto getFullDetail(Long placeId) {
        TourismPlace place = tourismRepository.findById(placeId)
                .orElseThrow(() -> new ResourceNotFoundException("Tourism place not found: " + placeId));
        place.setViewersCount(place.getViewersCount() + 1);

        TourismFullDetailDto dto = new TourismFullDetailDto();
        dto.setId(place.getId());
        dto.setName(place.getName());
        dto.setDescription(place.getDescription());
        dto.setWereda(place.getWereda());
        dto.setKebele(place.getKebele());
        dto.setBestTime(place.getBestTime());
        dto.setPeaceInfo(place.getPeaceInfo());
        dto.setVisitTime(place.getVisitTime());
        dto.setLanguages(place.getLanguages());
        dto.setViewersCount(place.getViewersCount());
        dto.setImages(place.getImages() != null ? place.getImages().stream().map(img -> img.getImageUrl()).toList() : List.of());
        dto.setRoads(roadInfoRepository.findByTourismPlaceId(placeId).stream().map(RoadInfoDto::fromEntity).toList());
        dto.setHotels(hotelRepository.findByTourismPlaceId(placeId).stream().map(HotelCardDto::fromEntity).toList());
        dto.setNearbyPlaces(tourismRepository.findTop5ByKebeleAndIdNotAndStatus(place.getKebele(), place.getId(), PlaceStatus.ACTIVE)
                .stream().map(NearbyTourismDto::fromEntity).toList());
        List<TourismRating> ratings = ratingRepository.findByTourismPlaceId(placeId);
        dto.setRatings(ratings.stream().map(TourismRatingResponseDto::fromEntity).toList());
        double avgRating = ratings.isEmpty() ? 0 : ratings.stream().mapToInt(TourismRating::getRating).average().orElse(0);
        dto.setRatingSummary(new RatingSummaryResponseDto(avgRating, (long) ratings.size()));
        return dto;
    }

    @Override
    public List<Hotel> getHotels(Long tourismPlaceId) {
        return hotelRepository.findByTourismPlaceId(tourismPlaceId);
    }

    @Override
    public List<RoadInfo> getRoadInfo(Long tourismPlaceId) {
        return roadInfoRepository.findByTourismPlaceId(tourismPlaceId);
    }
}
