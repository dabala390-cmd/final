package com.northwollo.tourism.service;

import com.northwollo.tourism.dto.request.HorseServiceCreateDto;

public interface HorseServiceService {

    Long create(HorseServiceCreateDto dto);

    void delete(Long id);
}
