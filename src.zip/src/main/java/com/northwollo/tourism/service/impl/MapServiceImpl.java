package com.northwollo.tourism.service.impl;

import com.northwollo.tourism.dto.response.MapRouteResponseDto;
import com.northwollo.tourism.service.MapService;
import org.springframework.stereotype.Service;

@Service
public class MapServiceImpl implements MapService {

    @Override
    public MapRouteResponseDto calculateRoute(String from, String to) {
        // TODO: implement map route calculation
        return new MapRouteResponseDto();
    }
}
