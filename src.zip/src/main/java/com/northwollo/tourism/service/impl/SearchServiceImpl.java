package com.northwollo.tourism.service.impl;

import com.northwollo.tourism.dto.response.SearchResultDto;
import com.northwollo.tourism.dto.response.TourismListDto;
import com.northwollo.tourism.entity.TourismPlace;
import com.northwollo.tourism.enums.PlaceStatus;
import com.northwollo.tourism.enums.TourismCategory;
import com.northwollo.tourism.repository.TourismPlaceRepository;
import com.northwollo.tourism.service.SearchService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class SearchServiceImpl implements SearchService {

    private final TourismPlaceRepository repository;

    @Override
    public SearchResultDto<TourismListDto> searchTourismPlaces(
            List<TourismCategory> categories,
            String keyword,
            Pageable pageable
    ) {
        // Ensure popularity ordering
        Pageable sortedPageable = PageRequest.of(
                pageable.getPageNumber(),
                pageable.getPageSize(),
                Sort.by(Sort.Direction.DESC, "viewersCount")
        );

        // ✅ Use the correct repository method name
        Page<TourismPlace> page = repository.searchPublic(
                categories == null || categories.isEmpty() ? null : categories,
                keyword == null || keyword.isBlank() ? null : keyword,
                PlaceStatus.ACTIVE,
                sortedPageable
        );

        SearchResultDto<TourismListDto> result = new SearchResultDto<>();
        result.setContent(
                page.getContent().stream()
                        .map(this::mapToDto)
                        .toList()
        );
        result.setPage(sortedPageable.getPageNumber());
        result.setSize(sortedPageable.getPageSize());
        result.setTotalElements(page.getTotalElements());

        return result;
    }

    private TourismListDto mapToDto(TourismPlace place) {
        TourismListDto dto = new TourismListDto();
        dto.setId(place.getId());
        dto.setName(place.getName());

        // ✅ Get first image URL if available
        String imageUrl = null;
        if (place.getImages() != null && !place.getImages().isEmpty()) {
            imageUrl = place.getImages().get(0).getImageUrl();
        }
        dto.setImageUrl(imageUrl);

        dto.setViewersCount(place.getViewersCount());
        return dto;
    }
}
