package com.northwollo.tourism.service;

import com.northwollo.tourism.dto.response.SearchResultDto;
import com.northwollo.tourism.dto.response.TourismListDto;
import com.northwollo.tourism.enums.TourismCategory;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface SearchService {

    SearchResultDto<TourismListDto> searchTourismPlaces(
            List<TourismCategory> categories,
            String keyword,
            Pageable pageable
    );
}
